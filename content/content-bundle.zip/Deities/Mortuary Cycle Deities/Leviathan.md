---
created: Monday, December 11th 2023, 8:03:47 pm
modified: Monday, December 11th 2023, 9:45:24 pm
aliases: 
tags: 
---
> [!infobox|right]+
> # Leviathan
> | **Greater Deity** | **Pantheon**                    |
> | ------------------------ | ------------------------------- |
> |  **Symbol:**              | Silver serpent wrapped around a circular gem (sapphire or lapis lazuli) in a spiral          |
> |  **Home Plane:**          | Where the deity mainly resides  |
> |  **Alignment:**           | Neutral good         |
> | **Portfolio:**           | Sea,  |
> | **Worshipers:**          | Who mainly worships the deity   |
> | **Cleric Alignments:**   | CG, LG, N, NG  |
> | **Domains:**             | Domains that the deity controls |
> | **Favored Weapons:**     | Name of weapon (weapon type)    |

*The Silver Serpent, The World Serpent, Other name, etc*

// Paragraph 1 talks about the appearance, personality, and other traits of the deity

// Paragraph 2 talks about the church of the deity, its history, its organization, and what they do, or this paragraph talks in general about the deity's worshipers, who and what they are, and how they worship the deity

// Paragraph 3 talks about the clerics of the deity, when and how they pray, what they celebrate, what they typically do and don't do, and what they often multiclass with

**History/Relationships:** // Information of how the deity came into being, or how it acquired its present status, as well as which deities it considers allies or enemies

**Dogma:** // The basic tenets of the creed or teachings of the deity

**Clergy and Temples:** // Details of how the clerics of the deity act and the types of temples or shrines dedicated to the deity

## Deity Name (game Stat block)
// This contains their normal stats and abilities as a deity

### Other Divine Powers
// Paragraph 1 in this section explains how the divine status of the deity affect their die rolls

**Senses:** // The distance to which the senses of the deity are effective (# of miles equal to its divine rank), plus other facts related to the perception of the deity to the events around it

**Portfolio Sense:** The types of events the deity can sense that is related to their portfolio

**Automatic Actions:** Activities that the deity can perform as free actions (free actions consume no time and can be performed during its turn and still move and act)

**Create Magic Items:** Kinds of magic items the deity can create without needing an item creation feat, but the deity is still required to spend time and experience points to create the items

## Avatars
// Paragraph 1 talks about the characteristics, like visual or behavioral, of the avatar of the deity

**Avatar of Deity Name:** // Stats of the avatar of the deity, typically cut in half