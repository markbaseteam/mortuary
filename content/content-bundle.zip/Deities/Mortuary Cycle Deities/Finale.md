---
created: Tuesday, August 29th 2023, 5:05:01 pm
modified: Tuesday, December 12th 2023, 8:25:43 pm
aliases: 
tags: 
---
The eldest deity that came into being in the First Cycle. It is the god of finality, the denouement, and culmination. It was one of the first deities that ascended due to worship, and 

### Appearance
Moth like seraphim, either with blue and pink or rainbow colored wings and aura. Halo surrounding antennae. See YGO card Seraphim Papillion