---
created: Thursday, September 14th 2023, 4:45:22 pm
modified: Monday, December 11th 2023, 9:56:12 pm
date created: Thursday, September 14th 2023, 4:45:22 pm
date modified: Sunday, December 3rd 2023, 1:31:26 pm
aliases: 
tags: 
---
*The Bronze Serpent, ..., Other name, etc*

| **Deity Rank (D,L,I,G)** | **Pantheon**                    |
| ------------------------ | ------------------------------- |
| **Symbol:**              | Description of symbol           |
| **Home Plane:**          | Where the deity mainly resides  |
| **Alignment:**           | Neutral Good         |
| **Portfolio:**           | Aspects that the deity embodies |
| **Worshipers:**          | Who mainly worships the deity   |
| **Cleric Alignments:**   | Eligible alignments for clergy  |
| **Domains:**             | Domains that the deity controls |
| **Favored Weapons:**     | Name of weapon (weapon type)    |

// Paragraph 1 talks about the appearance, personality, and other traits of the deity

// Paragraph 2 talks about the church of the deity, its history, its organization, and what they do, or this paragraph talks in general about the deity's worshipers, who and what they are, and how they worship the deity

// Paragraph 3 talks about the clerics of the deity, when and how they pray, what they celebrate, what they typically do and don't do, and what they often multiclass with

**History/Relationships:** // Information of how the deity came into being, or how it acquired its present status, as well as which deities it considers allies or enemies

**Dogma:** // The basic tenets of the creed or teachings of the deity

**Clergy and Temples:** // Details of how the clerics of the deity act and the types of temples or shrines dedicated to the deity

## Deity Name (game Stat block)
// This contains their normal stats and abilities as a deity

### Other Divine Powers
// Paragraph 1 in this section explains how the divine status of the deity affect their die rolls

**Senses:** // The distance to which the senses of the deity are effective (# of miles equal to its divine rank), plus other facts related to the perception of the deity to the events around it

**Portfolio Sense:** The types of events the deity can sense that is related to their portfolio

**Automatic Actions:** Activities that the deity can perform as free actions (free actions consume no time and can be performed during its turn and still move and act)

**Create Magic Items:** Kinds of magic items the deity can create without needing an item creation feat, but the deity is still required to spend time and experience points to create the items

## Avatars
// Paragraph 1 talks about the characteristics, like visual or behavioral, of the avatar of the deity

**Avatar of Deity Name:** // Stats of the avatar of the deity, typically cut in half

---
Eldest son of Leviathan, twin of Sahar, and the God of Living Death/Lingering Life. Also known as the bronze serpent of the new moon. 

Since becoming a revenant:
- decrease in feeling certain strong emotions
	- happiness, fear, and anger are severely affected
		- e.g. unable to feel joy, but able to feel content; unable to feel anxious, but able to feel worry; unable to feel mad, but able to feel annoyed
- increase in standing by his moral code
## Appearance
He has light bronze skin with hazel eyes and black hair. The left side of his face and left arm are ghostly and wispy white as they were healed by [[phasm]] when he was hurt as a champion of Morrigan, though normally he hides it either with clothing or with illusions if interacting with mortals.

As one of the Children of Leviathan, he inherited his fathers form: that of a sea serpent. His sea serpent form is fairly monstrous in size, but pales in comparison of his father who can encircle the globe. In this form, he has deep weathered bronze scales with blue green patina accents.

## Abilities
Being a demigod, Salim inherits his father's form and to a lesser degree, some of his abilities. He is able to "shift" into a large serpent form, although significantly smaller than the world serpent, he is still quite large,

## Affiliations
### Champions


#### Novus
