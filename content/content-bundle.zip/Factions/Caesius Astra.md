---
Affiliated: "[[Norant]]"
tags:
  - Worldbuilding
  - Intelligence
  - Agency
---
<!--- Etymology: Caesius is Latin for light blue, sky blue; Stella is Latin for star --->
The civilian foreign intelligence service for Norant. It has limited jurisdiction within the city state's territory, and is tasked with information gathering, processing, and analyzing national security from around the world via human intelligence and conducting covert action. It has no law enforcement function and has little domestic intelligence collection.
#### Basic Info
| Overview    | Info |
| ----------- | ---- |
| **Abbreviation** | CAAS |
| **Motto**       |      |

