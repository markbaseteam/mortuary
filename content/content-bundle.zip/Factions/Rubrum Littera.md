---
Affiliated: "[[Norant]]"
tags:
  - Worldbuilding
  - Intelligence
  - Agency
---
<!--- Etymology: Rubrum is Latin for red, Littera is Latin for literature or letter --->
The domestic and public facing investigation service for Norant. It has jurisdiction over most of the city state's white collar crimes. Unlike the other agencies, they have full function over domestic territory, while having minimal function in other territories. They also act as one of the two state security agencies.
#### Basic Info
| Overview         | Info |
| ---------------- | ---- |
| **Abbreviation** | RUBI |
| **Motto**        |      |
|                  |     |
