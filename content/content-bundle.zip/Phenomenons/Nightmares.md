Nightmares are fragmented and chaotic beings, able to tear through the veil and primarily reside in the Layer associated with the Cycle in which they lived. They are considered undead creatures.

