The concept of undead in the Mortuary Cycle is not clear cut "evil" like in many other tales or worlds. The undead can be as good and benign as they can be evil and vicious. The term undead encompasses many individuals and creatures that have returned as the living dead in one way or another, and specific terms can be attributed to what the original creature or individual was, how they were brought back, or how they continue to "live" in the mortal world. Some terms aren't as concrete as others, and origins for creatures and individuals that would be under the same term can vary.

## Revenant
Rare undead that do not have clear reason how or why they are brought back to life, but appears to be influenced at the anima level.


**Notable Revenants:** Salim