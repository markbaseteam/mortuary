---
aliases: 
tags: 
date created: Monday, September 25th 2023, 4:45:43 pm
date modified: Sunday, December 3rd 2023, 1:30:02 pm
---
*The sleeping power*
Prehistoric essence of hope instilled in all living beings native to the world. 
<!--description needs rework-->

What are the properties of sovum?
* it exists within natives of the world
* it can be wielded by anyone who has it
* it is able to convert hope into power
* 