---
created: Monday, December 4th 2023, 7:59:43 am
modified: Friday, December 8th 2023, 2:18:58 am
aliases: 
tags:
  - Worldbuilding
  - Incomplete
Status:
  - In Progress
---

The Nefran calendar is the widely used solar calendar. 

|         Calendar | Day 1    | Day 2    | Day 3    | Day 4     | Day 5    | Day 6    | Day 7    |
| ----------------:| -------- | -------- | -------- | --------- | -------- | -------- | -------- |
| Gregorian (ours) | Sunday   | Monday   | Tuesday  | Wednesday | Thursday | Friday   | Saturday |
|           Nefran | Solmera  | Lumera   | Bemera   | Gimera    | Dalmera  | Themera  | Sinmera  |
|            Vashi | Ari-avin | Ari-afan | Ari-asen | Ari-akon  | Ari-anun | Ari-apyn | Ari-arwn |


````ad-note
title: About Days

There are 24 hours in a day, and 7 days in a week. Using custom times and days per week can exert unecessary confusion and frustration with Players since it is unlikely they will have a constant analog to help them remember.

**Suffix**
Each day ends in -mera, which is a shortened version of Modern Greek ημέρα (iméra) meaning day. It is derived from Ancient Greek, ἡμέρᾱ (hēmérā), which in itself is a lengthened form of ἦμᾰρ (êmar).
```ad-subnote
title: Prefix Etymology
**Solmera** 
Sol- is derived from Latin sol meaning sun.

**Lumera**
Lu- is derived from a shortened version of Latin luna meaning moon.

**Bemera**
Be- is derived from a shortened version of Phoenician beth, the second letter of Phoenician abjad. 

**Gimera**
Gi- is derived from a shortened version of Phoenician gimel, the third letter of Phoenician abjad. 

**Dalmera**
Dal- is derived from a shortened version of Phoenician daleth, the fourth letter of Phoenician abjad.

**Themera**
The- is derived from a shortened version of Greek theta, the eigth letter of the Greek alphabet.

**Sinmera**
Sin- is derived from Phoenician šin, the twenty first letter of the Phoenician abjad.
```
````

| Month | Season       | Ours      | Alt Names |
| ----- | ------------ | --------- | --------- |
|       | Midwinter    | January   |           |
|       | Late Winter  | February  |           |
|       | Early Spring | March     |           |
|       | Midspring    | April     |           |
|       | Late Spring  | May       |           |
|       | Early Summer | June      |           |
|       | Midsummer    | July      |           |
|       | Late Summer  | August    |           |
|       | Early Autumn | September |           |
|       | Midautumn    | October   |           |
|       | Late Autumn  | November  |           |
|       | Early Winter | December  |           |


## Tasks
- [ ] Research other fantasy calendars for inspiration ➕ 2023-12-03 
- [ ] Research modern and historical calendars ➕ 2023-12-03 
- [ ] Compile different lunar and solar calendar examples 🔼  ➕ 2023-12-03

## References
