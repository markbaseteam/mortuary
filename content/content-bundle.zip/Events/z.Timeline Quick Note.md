## Prior to Layer History
The history of the planet before the creation of the Layer era is shrouded in history, and can only be theorized by the select few who know about the Veil, Layers, and the connection between them, the Great Power, and deific powers of the gods themselves. The artificial satellite that orbit the planet is believed to have been created even before the First Layer, and predates all gods.

The First Layer is the most ancient layer in the Veil, and is as old as the Veil itself. With the First Layer being the echo of the world when the first apocalypse occurred, it is the only insight others can gleam from the era before the Great Power and the start of the Mortuary Cycle.

## Previous Layers' History
