---
# Fantasy Calendar/Aprils' Automatic Timeline info
fc-display-name: Nim's Destruction
fc-date: 1-1-1000
aat-render-enabled: true
timelines: [ancient history, era 2, nim]
aat-event-body: >-
 Nim, a powerful trading city nation and the prime knowledge center of the world
 at that time, was mysteriously and utterly destroyed one night during a storm.
 No one that was in the city survived.
---

## Public Knowledge
[[Nim]] was a powerhouse in the past, prior to its status as an academic and prosperous city state situated on the ancient -- isthmus —the lost land bridge connecting {continent 1} and {continent 2}— it was an independent trading post that was used by merchants traveling between {country 1} and {country 2}. 

The populace of the modern era knows about the city's destruction due to popular folklore that range from it being destroyed by a storm to sinking under the sea.

Nim's destruction remains a mystery, even to this day scholars squabble amongst each other about whether its destruction was divine punishment, natural cause, or brought upon by a monster of the deep or another plane.

## Gamemaster Knowledge
```blur
Nim was a rich city, 

As with most cities in ancient times, Nim worshipped Leviathan as their patron deity. Their worship of him played a role even before their rapid rise as the permanent residential fishermen and sailors prayed to him for their saftey out on sea and to protect the town from destructive waves and storms.

**Fate:** The destruction of Nim was a tragic occurance, as it was an accident on the part of Leviathan. Nim's local politics had become so corrupted due to gentrification from {country 2} that widened the local wealth gap to such a degree that Nim hosted the largest homeless population in the ancient world at that time. And with the zealotry of Serpent's Crest, the old and defunct worshipping body of Leviathan, claiming that the misfortune of poor were of their own doing, and constant claims that they were acting on behalf of their deity's will, Leviathan himself succumbed to uncontrolled fury which resulted in sand liquidfication and a tsunami that wiped out the city.
```