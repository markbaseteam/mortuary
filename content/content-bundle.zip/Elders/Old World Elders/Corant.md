#### Notes
* inspired by Belle and Beast in Belle (conceptual wise)
* Corant is akin to Belle, a singer and appreciator of musical arts
	* the thing he constantly aches for are the songs and the ability to play them while mobile
* Trayvum is akin to Beast, although never having horns in the Old World, he is the Beast aspect of Corant when the remerge into their true god form
* his true god form is larger, has four arms (two lighter color, two black {the right lighter arm has dark patterns streaking across it, representing the Surge scars}, two legs, 6 wings {left side black, right side pale gold}, 4 eyes {2 of which tend to be closed}, hair partitioned to be half pale gold with gold tips and black with violet tips, 2 horns, and a halo cut into two halves)
	* he is afraid of his true form as he feels disconnected from reality and himself, and feared to be easily swayed into falling into his desire to purge to world and remake it to be "perfect" yet again
---

The only Old World Elder still living in the modern era. Until recent events, Corant's identity was shrouded in the façade of his idol in the Old World who was lost to the original Calamity that brought about the Mortuary Cycle. As the being who worked endlessly behind the scenes to break the Mortuary Cycle, he finds himself lost in the current affairs of the world after he is successful in his mission.

## Appearance
Corant is humanoid with medium height, pale blond hair that fade into light gold, and light green eyes. He has pale skin with scars on the right side of his neck and shoulder. His right arm is scaly and sickly dark, and his fingernails of his right hand is long and monstrous.

After remerging back with Trayvum, he mainly looks the same, but now has a black streak in his hair that fades to navy blue, and copper eyes. His right arm is not scalely anymore, but has patterns of moving shadows. When he uses Skiastereos, his hair turns all black with a pale gold streak, and red violet eyes. When he uses Phostereos, he returns back to his "default" look. Only his eyes change color when using Lykofostereos, changing to a shade of deep purple.

## Powers
~~**Resonance Mimicry:** Able to temporarily mimic the powers of others by listening to their resonance. He is able to mimic reverberances, but only if he can trace the hidden song, usually by trying to identify the original identity of the inert resonance. He is unable to mimic those with spirits as they do not have songs. He is also unable to mimic echoes as their songs are distorted in a cacophony. Corant is able to mimic powers for a longer period of time if the resonance was recorded in crystal.

**Phostereos:** Ability to conjure solid light (or solidify light, unsure). Borderline creation magic. 

**Lykofostereos:** Ability to conjure solid light and shadow. (Only after merging with Travum)