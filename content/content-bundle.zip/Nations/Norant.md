---
aliases: 
tags:
  - Worldbuilding
  - Intelligence
  - CityState
established: 
status:
  - In Progress
date created: Sunday, November 26th 2023, 5:51:54 pm
date modified: Sunday, December 3rd 2023, 1:38:05 pm
---
## History


## Notable Features & Places


## Notable Figures


## Agencies

### [[Rubrum Littera]]
<!--- Etymology: Rubrum is Latin for red, Littera is Latin for literature or letter --->
The domestic and public facing investigation service for Norant. It has jurisdiction over most of the city state's white collar crimes. Unlike the other agencies, they have full function over domestic territory, while having minimal function in other territories. They also act as one of the two state security agencies. 

### [[Caesius Astra]]
<!--- Etymology: Caesius is Latin for light blue, sky blue; Stella is Latin for star --->
The civilian foreign intelligence service for Norant. It has limited jurisdiction within the city state's territory, and is tasked with information gathering, processing, and analyzing national security from around the world via human intelligence and conducting covert action. It has no law enforcement function and has little domestic intelligence collection.

