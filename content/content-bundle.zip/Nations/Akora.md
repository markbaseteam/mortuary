**Formal Name:**
**Capital:**
**Major Cities:** 
**Ruler:**
**Dominant Population:**
**Primary Languages:**
**Primary Worship:**
**Resources:**
**Allies:**
**Enemies:**

**Peoples:** Humans, Elves
**Languages:** Common (alnure), Elvish (tanryl)
**Writing System:** Common (alnure), Elvish

Formal Name: Calastian Dominion of Ankila
Capital: Sussephra
Major Cities: Ardenai, Hedo, Merlahn, Port Segoura
Ruler: High Minister Arnes Riven (LE human male)
Dominant Population: Human
Primary Languages: Calastian, Zathisk
Primary Worship: Chardun, Hedrada
Resources: Clay, fish, lumber
Allies: Calastian Hegemony
Enemies: Burok Torn, Durrover
