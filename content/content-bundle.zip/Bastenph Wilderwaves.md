---
created: Thursday, June 1st 2023, 12:01:25 am
modified: Sunday, December 3rd 2023, 9:10:21 pm
aliases: 
tags: 
---
Oceanic region that has been separated from the world for most of their history due to the wildwaves that surround it. Many islands are located in this region, including some larger ones, almost all of which contain <mark style="background: #FFB86CA6;">sudol'certa</mark>, terror lizards that similar to dinosaurs. 

## Asustar
An isolated