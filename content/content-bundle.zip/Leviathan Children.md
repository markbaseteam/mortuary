---
created: Sunday, April 9th 2023, 9:16:58 am
modified: Sunday, December 3rd 2023, 9:10:07 pm
aliases: 
tags: 
---
## The Great Five Children of Leviathan

### Eldest Twins
The eldest children of Leviathan and Asherah. Salim and Sahar are inspired by the twin gods --Salim and Sahar-- of the Canaanite religion, and represent dusk and dawn, as well as the "Evening Star" and "Morning Star" respectively. 

#### Salim

##### Mask of Uthur
Similar to primordials which have resonance that echoes with memories of their past lives, Salim's essence is also partially made up of a singular ancient primordial. After he became Morrigan's Paramount, but before he had his first children, Salim had already become very familiar of traversal in the veil up to the 5th Layer. During this time, he finally achieved going to the 4th Layer, in which his continued exposure of the layer resulted in him developing his **Mask of Uthur**. After he had his first children, ascended to godhood, and strived to be independent of Morrigan, he tried to explore the deeper layers, but could go no further than the 4th Layer.

Later when he had his second set of children, Salim took in Nifedeline's child that was intended to be raised by Nifedeline's cult, all for the dragon to gorge upon the child later to absorb the accumulated energy and regenerate some of his lost power. Salim's tenacity to hide and protect the child from Nifedeline resulted in dragon's ire, and eventually lead to several but brief battles of the two. The destruction of these battles were immense to the local areas, and almost lead to Salim losing the child he adopted along with his own children. When Nifedeline ambushed Salim the final time, Salim dragged him to the 4th Layer where they battled ferociously for several days.

Being a dragon, Nifedeline's energy to battle never wavered, while Salim was starting to become exhausted which resulted in him getting severely hurt each time. As an attempt to get some sort of edge, Salim tore off his Mask of Uthur and awakened his latent abilities of his previous life. It allowed him to navigate the 4th Layer with ease, accurate premonition, heightened endurance, and access to ethereal powers akin to Nightmares. This allowed him to get an advantage over Nifedeline, and defeat the dragon.

##### Powers
**Lætan Grīma:** (Mask of Uthur) After tearing off the Mask of Uthur, new powers are born and old memories are awakened... except, for Salim, he has no memories of his past life. He *knows* various things of the 4th Cycle —though hardly of the 4th Layer— but has no memory of when or how he got such knowledge.

> **Past life:** 4th Layer, Aur Robora; apprentice to Faltrix who betrayed him to usher in the end of the 4th cycle. Had dark rustic brown hair with red tan tips, and bright red eyes.

Unlike modern primordials that are amalgamations of the essence from several ancient primordials due to being torn apart when they were Nightmares or suffered

##### Etymology
Salim is a variation of Shalim, the god of dusk/sunset of Canaanite religion. Shalim is derived from the Semitic triconsonantal root S-L-M, with the root translating as whole, safe, intact, unharmed, to go free or without blemish. Shalim can mean peace, peaceful, complete (like the end of the day), and sunset. Variations of Shalim are Šalām, Shalem, Salem, and Salim.

#### Sahar

### Eldest Triplets
The youngest children of Leviathan and Asherah.

**Rei**

**Salome**

**Yesmina**